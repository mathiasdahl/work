@echo off

REM                        WHAT IS THIS?

REM   This script will let you create documents and import files very
REM   easily. You just need to fill in some information in a CSV file.
REM
REM   The script relies on Test-A-Rest (aka TAR) to call the necessary
REM   projection. You can download it from here:
REM
REM     http://techdocs/demoshowroom/21r2/010_demo_platform/020_running_scripts/
REM
REM   Make sure to read the installation instructions there.
REM
REM   To use the script, configure the server URL, username, password
REM   and the path to Test-A-Rest on your machine by changing the four
REM   "set" commands in the section below.
REM
REM   Once the script works, edit the documents.csv file and put files
REM   to be imported in the files folder. Each row in the CSV file
REM   needs to point to a file to be uploaded to the new document.
REM

REM                     WHAT DOES IT DO EXACTLY?

REM   Right now, the script creates, for each row in documents.csv, a
REM   new document title, a document revision and a file
REM   reference. Then it uploads the file mentiones in the File column
REM   of the CSV file. The document number will be generated according
REM   to the settings for the document class.

REM   Future versions might include a way to easily connect objects to
REM   the new documents that are created. For now, that is left as an
REM   exercise to the reader... (Hint: Find a projection that allows
REM   connecting a document and an object, modify ImportDocument.mkd
REM   accordingly and add the necessary columns to documents.csv.)

REM   If you need to provide more details of each new document, find a
REM   projection that will allow you to modify each document, for
REM   example DocumentRevision.svc.

REM                     HOW IS THE PERFORMANCE?
REM
REM   It's quite good, thanks for asking. On my PC, using one of our
REM   support environments, I can import 100 small documents in 24
REM   seconds. Larger files takes more time, of course. The closer to
REM   the server you can run the script, the better (the overhead of
REM   each network call will take up a smaller part of the overall
REM   progress).
REM 

REM         *** CONFIGURATION SECTION BEGINS HERE ***

set serverurl=https://ifscloud21r2testlkp.rnd.ifsdevworld.com

REM  The root URL the server where you access IFS Cloud/Aurena .

REM  Example: https://ifscloud21r2testlkp.rnd.ifsdevworld.com

set username=jackie

REM  The username used to create and import the document

REM  Example: jackie

set password=jackie

REM  The password

REM  Example: jackie

set testarest="c:\Users\mdahse\OneDrive - IFS\Downloads\Test-A-Rest-v1.2.0.30_commandline\publish-commandline\TestARest.exe"

REM  The complete path and file name of Test-A-Rest installed on your
REM  machine. Make sure to enclose in double quotes if the path
REM  contains a space.

REM  Example: "c:\Users\mdahse\OneDrive - IFS\Downloads\Test-A-Rest-v1.2.0.30_commandline\publish-commandline\TestARest.exe"


REM          *** CONFIGURATION SECTION ENDS HERE ***


set file=ImportDocuments.mkd

> %file%  echo ```cs
>> %file% echo Print "Creating documents from documents.csv"
>> %file% echo ExecuteCsv documents.csv Using ImportDocument.mkd
>> %file% echo Print "Done"
>> %file% echo ```
>> %file% echo.

echo.
echo Importing documents from documents.csv...

%testarest% ServerUrl=%serverurl% Username=%username% Password=%password% FileToRead=%file% > ImportDocuments.log

echo Done. Any errors will be displayed above. Check ImportDocuments.log for details of the overall progress.
echo.

del %file%

pause
