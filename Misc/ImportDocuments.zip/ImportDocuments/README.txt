Open ImportDocuments.cmd in Notepad.

Read the instructions at the top of the file and edit the file accordingly.

Enjoy!

/Mathias Dahl, 2022-04-19
